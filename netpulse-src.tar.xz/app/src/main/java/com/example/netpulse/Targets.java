package com.example.netpulse;

import android.content.Context;
import android.content.SharedPreferences;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

final class Targets {
    static final String DEFAULT_CN =
            "百度 | https://www.baidu.com/\n" +
            "腾讯 | https://www.qq.com/\n" +
            "哔哩哔哩 | https://www.bilibili.com/\n" +
            "淘宝 | https://www.taobao.com/\n" +
            "京东 | https://www.jd.com/";
    static final String DEFAULT_GLOBAL =
            "Google | https://www.google.com/\n" +
            "GitHub | https://github.com/\n" +
            "Wikipedia | https://www.wikipedia.org/\n" +
            "YouTube | https://www.youtube.com/\n" +
            "Cloudflare | https://www.cloudflare.com/";
    static final String DEFAULT_CN_SPEED = "https://mirrors.tuna.tsinghua.edu.cn/debian/ls-lR.gz";
    static final String DEFAULT_GLOBAL_SPEED = "https://speed.cloudflare.com/__down?bytes=16000000";

    static final class Target {
        final String name;
        final String url;
        final boolean domestic;
        Target(String name, String url, boolean domestic) {
            this.name = name;
            this.url = url;
            this.domestic = domestic;
        }
    }

    private final SharedPreferences prefs;
    Targets(Context context) {
        prefs = context.getSharedPreferences("targets", Context.MODE_PRIVATE);
    }
    String domesticText() { return prefs.getString("domestic", DEFAULT_CN); }
    String globalText() { return prefs.getString("global", DEFAULT_GLOBAL); }
    String domesticSpeedUrl() { return prefs.getString("cnSpeed", DEFAULT_CN_SPEED); }
    String globalSpeedUrl() { return prefs.getString("globalSpeed", DEFAULT_GLOBAL_SPEED); }

    void save(String cn, String global, String cnSpeed, String globalSpeed) {
        prefs.edit().putString("domestic", cn.trim())
                .putString("global", global.trim())
                .putString("cnSpeed", cnSpeed.trim())
                .putString("globalSpeed", globalSpeed.trim()).apply();
    }

    List<Target> all() {
        List<Target> out = new ArrayList<>();
        out.addAll(parse(domesticText(), true));
        out.addAll(parse(globalText(), false));
        return out;
    }

    static List<Target> parse(String text, boolean domestic) {
        List<Target> out = new ArrayList<>();
        for (String raw : text.split("\\r?\\n")) {
            String line = raw.trim();
            if (line.isEmpty() || line.startsWith("#")) continue;
            if (out.size() >= 15) throw new IllegalArgumentException("每组最多 15 个网站");
            String[] parts = line.split("\\|", 2);
            String name, address;
            if (parts.length == 2) {
                name = parts[0].trim();
                address = parts[1].trim();
            } else {
                address = line;
                name = "";
            }
            if (!address.startsWith("https://")) {
                if (address.contains("://")) throw new IllegalArgumentException("只支持 HTTPS 地址：" + address);
                address = "https://" + address;
            }
            try {
                URL u = new URL(address);
                if (!"https".equalsIgnoreCase(u.getProtocol()) || u.getHost().isEmpty() ||
                        u.getUserInfo() != null) {
                    throw new IllegalArgumentException("无效 HTTPS 地址：" + address);
                }
                if (name.isEmpty()) name = u.getHost();
                out.add(new Target(name, address, domestic));
            } catch (Exception e) {
                throw new IllegalArgumentException("无法识别网站：" + line);
            }
        }
        return out;
    }

    static String requireHttps(String url) {
        try {
            URL u = new URL(url.trim());
            if (!"https".equalsIgnoreCase(u.getProtocol()) || u.getHost().isEmpty() ||
                    u.getUserInfo() != null) throw new IllegalArgumentException();
            return u.toString();
        } catch (Exception e) {
            throw new IllegalArgumentException("测速地址必须是完整的 HTTPS URL");
        }
    }
}
