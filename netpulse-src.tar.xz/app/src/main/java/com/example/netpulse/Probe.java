package com.example.netpulse;

import android.os.SystemClock;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

final class Probe {
    static final int ATTEMPTS = 3;
    private static final int MAX_HTML_BYTES = 256 * 1024;
    private static final String USER_AGENT = "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 " +
            "(KHTML, like Gecko) Chrome/125.0.0.0 Mobile Safari/537.36";

    interface CancelCheck { boolean cancelled(); }

    static final class Sample {
        double dnsMs = -1;
        double connectMs = -1;
        double responseMs = -1;
        double bodyMs = -1;
        int status = -1;
        int bytes = 0;
        boolean capped = false;
        String error = "";
        boolean responded() { return status >= 100; }
        boolean success() { return status >= 200 && status < 400; }
    }

    static final class Result {
        final Targets.Target target;
        final List<Sample> samples = new ArrayList<>();
        Result(Targets.Target target) { this.target = target; }
        int reached() {
            int n = 0;
            for (Sample s : samples) if (s.responded()) n++;
            return n;
        }
        int succeeded() {
            int n = 0;
            for (Sample s : samples) if (s.success()) n++;
            return n;
        }
        int lastStatus() {
            for (int i = samples.size()-1; i >= 0; i--) {
                if (samples.get(i).responded()) return samples.get(i).status;
            }
            return -1;
        }
        String lastError() {
            for (int i = samples.size()-1; i >= 0; i--) {
                if (!samples.get(i).error.isEmpty()) return samples.get(i).error;
            }
            return "无响应";
        }
        double medianResponse() { return median(1); }
        double medianBody() { return median(2); }
        double medianDns() { return median(3); }
        double medianConnect() { return median(4); }
        double jitter() {
            List<Double> vals = new ArrayList<>();
            for (Sample s : samples) if (s.responseMs >= 0) vals.add(s.responseMs);
            if (vals.size() < 2) return -1;
            double sum = 0;
            for (int i=1; i<vals.size(); i++) sum += Math.abs(vals.get(i) - vals.get(i-1));
            return sum / (vals.size()-1);
        }
        private double median(int which) {
            List<Double> vals = new ArrayList<>();
            for (Sample s : samples) {
                double v;
                switch(which) {
                    case 1: v=s.responseMs; break;
                    case 2: v=s.bodyMs; break;
                    case 3: v=s.dnsMs; break;
                    default: v=s.connectMs;
                }
                if (v >= 0 && (which >= 3 || s.responded())) vals.add(v);
            }
            if (vals.isEmpty()) return -1;
            Collections.sort(vals);
            int mid = vals.size() / 2;
            return vals.size()%2 == 1 ? vals.get(mid) : (vals.get(mid-1)+vals.get(mid))/2;
        }
    }

    static Result measure(Targets.Target target, CancelCheck check) {
        Result result = new Result(target);
        for (int i=0; i<ATTEMPTS; i++) {
            if (check.cancelled()) break;
            result.samples.add(measureOnce(target.url, check));
        }
        return result;
    }

    private static Sample measureOnce(String address, CancelCheck check) {
        Sample sample = new Sample();
        HttpURLConnection conn = null;
        try {
            URL url = new URL(address);
            // Run the actual HTTP request first so a separate DNS diagnostic does not
            // pre-warm the resolver cache and artificially improve HTTP timings.
            if (check.cancelled()) return sample;
            conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setConnectTimeout(4500);
            conn.setReadTimeout(5500);
            conn.setInstanceFollowRedirects(true);
            conn.setUseCaches(false);
            conn.setRequestProperty("Cache-Control", "no-cache");
            conn.setRequestProperty("Pragma", "no-cache");
            conn.setRequestProperty("Accept-Encoding", "identity");
            conn.setRequestProperty("Connection", "close");
            conn.setRequestProperty("User-Agent", USER_AGENT);
            conn.setRequestProperty("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");

            long start = SystemClock.elapsedRealtimeNanos();
            conn.connect();
            sample.connectMs = millisSince(start); // Includes DNS+TCP+TLS; redirects are later.
            sample.status = conn.getResponseCode();
            sample.responseMs = millisSince(start); // Response headers available (TTFB proxy).

            InputStream input = sample.status >= 400 ? conn.getErrorStream() : conn.getInputStream();
            if (input != null) {
                try (InputStream stream = input) {
                    byte[] buffer = new byte[8192];
                    int n;
                    while (sample.bytes < MAX_HTML_BYTES && !check.cancelled() &&
                            (n = stream.read(buffer, 0, Math.min(buffer.length, MAX_HTML_BYTES - sample.bytes))) != -1) {
                        sample.bytes += n;
                    }
                    sample.capped = sample.bytes == MAX_HTML_BYTES;
                    if (!check.cancelled()) sample.bodyMs = millisSince(start);
                } catch (IOException io) {
                    // The server responded, but transferring the body failed.
                    sample.error = "正文读取失败：" + humanError(io);
                }
            } else {
                sample.bodyMs = millisSince(start);
            }
        } catch (Exception ex) {
            sample.error = humanError(ex);
        } finally {
            if (conn != null) conn.disconnect();
        }
        // Supplementary DNS query, intentionally performed AFTER the HTTPS probe.
        // It may hit system cache and might not reflect DNS used by an HTTP proxy.
        if (!check.cancelled()) {
            long dnsStart = SystemClock.elapsedRealtimeNanos();
            try {
                InetAddress.getAllByName(new URL(address).getHost());
                sample.dnsMs = millisSince(dnsStart);
            } catch (IOException ignored) { }
        }
        return sample;
    }

    private static double millisSince(long beginNanos) {
        return (SystemClock.elapsedRealtimeNanos() - beginNanos) / 1_000_000d;
    }
    private static String humanError(Exception ex) {
        String text = ex.getLocalizedMessage();
        if (text == null || text.isEmpty()) text = ex.getClass().getSimpleName();
        if (text.length() > 90) text = text.substring(0,90);
        return text.replace('\n', ' ');
    }
}
