package com.example.netpulse;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

public final class MainActivity extends Activity {
    private static final int BG = Color.rgb(15, 21, 33);
    private static final int CARD = Color.rgb(27, 36, 53);
    private static final int TEXT = Color.rgb(238, 245, 255);
    private static final int MUTED = Color.rgb(161, 178, 198);
    private static final int BLUE = Color.rgb(111, 185, 255);
    private static final int GREEN = Color.rgb(113, 218, 175);
    private static final int ORANGE = Color.rgb(255, 199, 123);
    private static final int RED = Color.rgb(255, 139, 145);

    private final AtomicInteger generation = new AtomicInteger();
    private final Map<String, SiteView> siteViews = new HashMap<>();
    private final Map<String, Probe.Result> siteResults = new HashMap<>();
    private final List<SpeedTester.Result> speedResults = new ArrayList<>();
    private Targets targets;
    private LinearLayout cnContainer, globalContainer, speedContainer;
    private TextView networkLabel, summaryLabel, cnStats, globalStats, speedStatus;
    private Button startButton, speedButton, editButton, stopButton, shareButton;
    private ExecutorService executor;
    private Thread speedThread;
    private boolean busy;
    private ConnectivityManager connectivity;
    private ConnectivityManager.NetworkCallback netCallback;

    private static final class SiteView {
        TextView main, detail;
        ProgressBar bar;
    }

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        targets = new Targets(this);
        connectivity = (ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);
        createLayout();
        rebuildTargets();
        updateNetwork();
        if (Build.VERSION.SDK_INT >= 24 && connectivity != null) {
            netCallback = new ConnectivityManager.NetworkCallback() {
                @Override public void onAvailable(Network network) { runOnUiThread(() -> updateNetwork()); }
                @Override public void onLost(Network network) { runOnUiThread(() -> updateNetwork()); }
                @Override public void onCapabilitiesChanged(Network n, NetworkCapabilities c) {
                    runOnUiThread(() -> updateNetwork());
                }
            };
            try { connectivity.registerDefaultNetworkCallback(netCallback); }
            catch (Exception ignored) { netCallback = null; }
        }
    }

    private void createLayout() {
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        scroll.setVerticalScrollBarEnabled(false);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(18), dp(24), dp(18), dp(30));
        root.setBackgroundColor(BG);
        scroll.addView(root);
        setContentView(scroll);

        if (Build.VERSION.SDK_INT >= 30) {
            scroll.setOnApplyWindowInsetsListener((v, insets) -> {
                android.graphics.Insets bars = insets.getInsets(WindowInsets.Type.systemBars());
                scroll.setPadding(bars.left, bars.top, bars.right, bars.bottom);
                return insets;
            });
        } else {
            scroll.setFitsSystemWindows(true);
        }

        TextView eyebrow = label("NETWORK DIAGNOSTICS  /  CN + GLOBAL", 11, BLUE, true);
        root.addView(eyebrow);
        addSpace(root, 8);
        root.addView(label("NetPulse", 32, TEXT, true));
        addSpace(root, 3);
        root.addView(label("真实 HTTPS 响应延迟 · 国内外对比 · 实际吞吐", 13, MUTED, false));
        addSpace(root, 20);

        LinearLayout networkCard = card(root);
        networkCard.addView(label("当前 Android 默认网络", 13, MUTED, false));
        addSpace(networkCard, 5);
        networkLabel = label("读取网络状态中…", 16, TEXT, true);
        networkCard.addView(networkLabel);
        addSpace(root, 16);

        LinearLayout mainActions = horizontal(root);
        startButton = action("测试网站", BLUE, BG, true);
        speedButton = action("实际测速", CARD, TEXT, true);
        mainActions.addView(startButton, weightedButton());
        addHorizontalSpace(mainActions, 9);
        mainActions.addView(speedButton, weightedButton());
        addSpace(root, 9);
        LinearLayout secondary = horizontal(root);
        editButton = action("编辑节点", CARD, TEXT, false);
        shareButton = action("分享结果", CARD, TEXT, false);
        stopButton = action("停止", Color.rgb(82, 39, 48), RED, false);
        secondary.addView(editButton, weightedButton());
        addHorizontalSpace(secondary, 8);
        secondary.addView(shareButton, weightedButton());
        addHorizontalSpace(secondary, 8);
        secondary.addView(stopButton, weightedButton());
        stopButton.setEnabled(false);
        addSpace(root, 16);

        LinearLayout summary = card(root);
        summary.addView(label("本次网站测试", 12, MUTED, true));
        addSpace(summary, 6);
        summaryLabel = label("尚未开始", 21, TEXT, true);
        summary.addView(summaryLabel);
        addSpace(summary, 4);
        summary.addView(label("每个网站执行 3 次 HTTPS GET；比较响应头到达耗时的中位数", 12, MUTED, false));
        addSpace(root, 22);

        sectionTitle(root, "国内网站", "CN");
        cnStats = label("等待测试", 12, MUTED, false);
        root.addView(cnStats);
        addSpace(root, 10);
        cnContainer = new LinearLayout(this);
        cnContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(cnContainer);
        addSpace(root, 18);

        sectionTitle(root, "国际网站", "GLOBAL");
        globalStats = label("等待测试", 12, MUTED, false);
        root.addView(globalStats);
        addSpace(root, 10);
        globalContainer = new LinearLayout(this);
        globalContainer.setOrientation(LinearLayout.VERTICAL);
        root.addView(globalContainer);
        addSpace(root, 20);

        sectionTitle(root, "下载 / 上传速度", "REAL TRANSFER");
        LinearLayout speedCard = card(root);
        speedStatus = label("独立的 HTTPS 流量测试，不把网页 HTML 的下载速度当作宽带速度。", 12, MUTED, false);
        speedCard.addView(speedStatus);
        addSpace(speedCard, 9);
        speedContainer = new LinearLayout(this);
        speedContainer.setOrientation(LinearLayout.VERTICAL);
        speedCard.addView(speedContainer);
        addSpace(root, 17);

        TextView caution = label("说明：这里的“首响应”是 HTTPS 请求开始到 HTTP 响应头到达，包含 DNS / TCP / TLS / 服务端处理；不等于 ICMP Ping。"+
                "正文最多读取 256 KiB，不执行 JavaScript，也不代表浏览器完整渲染。单线程下载更接近单个文件的实际速度，而非运营商理论峰值。", 12, MUTED, false);
        caution.setLineSpacing(dp(3),1f);
        root.addView(caution);

        startButton.setOnClickListener(v -> testSites());
        speedButton.setOnClickListener(v -> testSpeed());
        editButton.setOnClickListener(v -> editTargets());
        shareButton.setOnClickListener(v -> shareResults());
        stopButton.setOnClickListener(v -> cancelCurrent());
    }

    private void sectionTitle(LinearLayout root, String name, String marker) {
        LinearLayout row = horizontal(root);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.addView(label(name, 19, TEXT, true));
        addHorizontalSpace(row, 10);
        row.addView(label(marker, 11, BLUE, true));
        addSpace(root, 6);
    }

    private void rebuildTargets() {
        siteViews.clear();
        siteResults.clear();
        cnContainer.removeAllViews();
        globalContainer.removeAllViews();
        List<Targets.Target> all = targets.all();
        for (Targets.Target target : all) {
            SiteView sv = new SiteView();
            LinearLayout destination = target.domestic ? cnContainer : globalContainer;
            LinearLayout card = card(destination);
            LinearLayout heading = horizontal(card);
            heading.setGravity(Gravity.CENTER_VERTICAL);
            heading.addView(label(target.name, 17, TEXT, true));
            addHorizontalSpace(heading, 10);
            sv.main = label("—", 20, MUTED, true);
            LinearLayout.LayoutParams right = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
            sv.main.setGravity(Gravity.END);
            heading.addView(sv.main, right);
            addSpace(card, 6);
            TextView domain = label(target.url, 11, MUTED, false);
            domain.setSingleLine(true);
            domain.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            card.addView(domain);
            addSpace(card, 9);
            sv.bar = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
            sv.bar.setMax(2000);
            sv.bar.setProgress(0);
            sv.bar.setProgressTintList(ColorStateList.valueOf(BLUE));
            sv.bar.setProgressBackgroundTintList(ColorStateList.valueOf(Color.rgb(48,61,79)));
            card.addView(sv.bar,new LinearLayout.LayoutParams(-1,dp(5)));
            addSpace(card, 9);
            sv.detail = label("等待测试", 12, MUTED, false);
            sv.detail.setLineSpacing(dp(3),1f);
            card.addView(sv.detail);
            siteViews.put(target.url + (target.domestic ? "CN" : "GL"),sv);
            addSpace(destination, 9);
        }
        summaryLabel.setText("尚未开始");
        cnStats.setText("等待测试");
        globalStats.setText("等待测试");
    }

    private void testSites() {
        if (busy) return;
        int id = generation.incrementAndGet();
        List<Targets.Target> selected = targets.all();
        if (selected.isEmpty()) { toast("先添加 HTTPS 网站"); return; }
        siteResults.clear();
        for (SiteView sv : siteViews.values()) {
            sv.main.setText("测试中…");
            sv.main.setTextColor(BLUE);
            sv.detail.setText("HTTPS → 响应头 → 正文；DNS 参考单独测量");
            sv.bar.setProgress(0);
        }
        summaryLabel.setText("正在测试 0 / " + selected.size());
        cnStats.setText("正在进行…");
        globalStats.setText("正在进行…");
        setBusy(true);
        executor=Executors.newFixedThreadPool(4);
        ExecutorService current=executor;
        AtomicInteger finished=new AtomicInteger();
        for (Targets.Target target : selected) {
            current.execute(() -> {
                Probe.Result result = Probe.measure(target,
                        () -> Thread.currentThread().isInterrupted() || generation.get()!=id);
                if (generation.get()!=id) return;
                runOnUiThread(() -> {
                    if (generation.get()!=id) return;
                    siteResults.put(target.url + (target.domestic ? "CN" : "GL"),result);
                    renderResult(result);
                    updateGroupStats(selected);
                    int done=finished.incrementAndGet();
                    summaryLabel.setText(done==selected.size() ? "完成 " + done + " 个网站" :
                            "正在测试 " + done + " / " + selected.size());
                });
            });
        }
        current.shutdown();
        new Thread(() -> {
            try { current.awaitTermination(4,TimeUnit.MINUTES); }
            catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
            runOnUiThread(() -> { if (generation.get()==id) setBusy(false); });
        },"NetPulse-SiteWait").start();
    }

    private void renderResult(Probe.Result result) {
        SiteView sv = siteViews.get(result.target.url + (result.target.domestic ? "CN":"GL"));
        if (sv==null) return;
        double ms = result.medianResponse();
        if (ms<0) {
            sv.main.setText("不可达");
            sv.main.setTextColor(RED);
            sv.detail.setText("请求失败：" + result.lastError() + "\n"+
                    "尝试 " + result.samples.size() + " 次；DNS 参考 " + fmt(result.medianDns()));
            sv.bar.setProgress(0);
        } else {
            int status=result.lastStatus();
            boolean good=result.succeeded()>0;
            int tone=good ? GREEN : ORANGE;
            sv.main.setText(fmt(ms));
            sv.main.setTextColor(tone);
            sv.bar.setProgress((int)Math.min(2000,Math.max(0,ms)));
            sv.bar.setProgressTintList(ColorStateList.valueOf(tone));
            sv.detail.setText("HTTP " + status + " · 响应 " + result.reached() + "/"+Probe.ATTEMPTS+
                    " · 抖动 " + fmt(result.jitter()) + "\n"+
                    "DNS参考 " + fmt(result.medianDns()) + " · HTTPS连接 " + fmt(result.medianConnect())+
                    " · 正文读取累计 " + fmt(result.medianBody()));
        }
    }

    private void updateGroupStats(List<Targets.Target> selected) {
        for (boolean domestic : new boolean[]{true,false}) {
            int total=0, tested=0, reachable=0;
            List<Double> values=new ArrayList<>();
            for (Targets.Target target : selected) {
                if (target.domestic!=domestic) continue;
                total++;
                Probe.Result r=siteResults.get(target.url + (target.domestic ? "CN":"GL"));
                if (r==null) continue;
                tested++;
                if (r.reached()>0) reachable++;
                if (r.medianResponse()>=0) values.add(r.medianResponse());
            }
            Collections.sort(values);
            double middle=-1;
            if (!values.isEmpty()) {
                int p=values.size()/2;
                middle=values.size()%2==0 ? (values.get(p-1)+values.get(p))/2 : values.get(p);
            }
            String stats=String.format(Locale.CHINA,
                    "有响应 %d/%d 站 · 已测试 %d/%d · 首响应中位数 %s",
                    reachable,total,tested,total,fmt(middle));
            (domestic ? cnStats : globalStats).setText(stats);
        }
    }

    private void testSpeed() {
        if (busy) return;
        int id=generation.incrementAndGet();
        speedResults.clear();
        speedContainer.removeAllViews();
        speedStatus.setText("正在进行实际下载 / 上传（总流量通常不超过 40 MB）…");
        setBusy(true);
        speedThread = new Thread(() -> {
            Probe.CancelCheck check=() -> Thread.currentThread().isInterrupted() || generation.get()!=id;
            String cn=targets.domesticSpeedUrl();
            String global=targets.globalSpeedUrl();
            SpeedTester.Result a=SpeedTester.download("国内下载",cn,check);
            appendSpeedResult(id,a);
            if (check.cancelled()) return;
            SpeedTester.Result b=SpeedTester.download("国际下载",global,check);
            appendSpeedResult(id,b);
            if (check.cancelled()) return;
            SpeedTester.Result c=SpeedTester.uploadCloudflare(check);
            appendSpeedResult(id,c);
            runOnUiThread(() -> {
                if (generation.get()!=id) return;
                speedStatus.setText("完成 · 单连接 HTTPS 吞吐；更换节点可比较路由差异。");
                setBusy(false);
            });
        },"NetPulse-Speed");
        speedThread.start();
    }

    private void appendSpeedResult(int id,SpeedTester.Result res) {
        runOnUiThread(() -> {
            if (generation.get()!=id) return;
            speedResults.add(res);
            TextView line=label(res.label(),15,res.ok()? GREEN:RED,res.ok());
            speedContainer.addView(line);
            addSpace(speedContainer, 9);
            speedStatus.setText("已完成 " + speedResults.size() + "/3 项，正在继续…");
        });
    }

    private void setBusy(boolean running) {
        busy=running;
        startButton.setEnabled(!running);
        speedButton.setEnabled(!running);
        editButton.setEnabled(!running);
        stopButton.setEnabled(running);
        startButton.setAlpha(running?.5f:1f);
        speedButton.setAlpha(running?.5f:1f);
        editButton.setAlpha(running?.5f:1f);
    }

    private void cancelCurrent() {
        generation.incrementAndGet();
        if (executor!=null) executor.shutdownNow();
        if (speedThread!=null) speedThread.interrupt();
        setBusy(false);
        summaryLabel.setText("已停止（已完成结果保留）");
        speedStatus.setText("已停止；网络操作可能在超时前结束。");
    }

    private void editTargets() {
        if (busy) return;
        ScrollView scroll = new ScrollView(this);
        LinearLayout content = new LinearLayout(this);
        content.setPadding(dp(20),dp(14),dp(20),dp(6));
        content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        TextView hint=label("每行一项：名称 | https://网址。每组最多 15 项；修改后保存。",12,MUTED,false);
        content.addView(hint);
        addSpace(content,12);
        content.addView(label("国内网站",14,TEXT,true));
        EditText cn=editor(targets.domesticText(),5);
        content.addView(cn);
        addSpace(content,11);
        content.addView(label("国际网站",14,TEXT,true));
        EditText global=editor(targets.globalText(),5);
        content.addView(global);
        addSpace(content,11);
        content.addView(label("国内下载测速文件（HTTPS）",14,TEXT,true));
        EditText cnSpeed=editor(targets.domesticSpeedUrl(),2);
        content.addView(cnSpeed);
        addSpace(content,11);
        content.addView(label("国际下载测速地址（HTTPS）",14,TEXT,true));
        EditText globalSpeed=editor(targets.globalSpeedUrl(),2);
        content.addView(globalSpeed);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("编辑测试目标")
                .setView(scroll)
                .setNegativeButton("取消",(d,w)->{})
                .setNeutralButton("恢复默认",(d,w)->{
                    targets.save(Targets.DEFAULT_CN,Targets.DEFAULT_GLOBAL,
                            Targets.DEFAULT_CN_SPEED,Targets.DEFAULT_GLOBAL_SPEED);
                    rebuildTargets();
                })
                .setPositiveButton("保存",null).create();
        dialog.setOnShowListener(v -> dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(btn -> {
            try {
                String cnText=cn.getText().toString();
                String globalText=global.getText().toString();
                Targets.parse(cnText,true);
                Targets.parse(globalText,false);
                String cnLink=Targets.requireHttps(cnSpeed.getText().toString());
                String globalLink=Targets.requireHttps(globalSpeed.getText().toString());
                targets.save(cnText,globalText,cnLink,globalLink);
                rebuildTargets();
                dialog.dismiss();
                toast("节点已保存");
            } catch(Exception ex) { toast(ex.getMessage()); }
        }));
        dialog.show();
    }

    private EditText editor(String value, int lines) {
        EditText input=new EditText(this);
        input.setText(value);
        input.setTextSize(13);
        input.setTextColor(TEXT);
        input.setHintTextColor(MUTED);
        input.setBackground(round(Color.rgb(38,48,67),10));
        input.setPadding(dp(12),dp(8),dp(12),dp(8));
        input.setInputType(android.text.InputType.TYPE_CLASS_TEXT|
                android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE|
                android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS);
        input.setMinLines(lines);
        input.setGravity(Gravity.TOP | Gravity.START);
        return input;
    }

    private void shareResults() {
        if (siteResults.isEmpty() && speedResults.isEmpty()) { toast("先执行一次测试"); return; }
        StringBuilder report=new StringBuilder();
        report.append("NetPulse 网络测试报告\n")
                .append(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.CHINA).format(new Date()))
                .append("\n").append(networkLabel.getText()).append("\n\n");
        for (Targets.Target t : targets.all()) {
            Probe.Result r=siteResults.get(t.url+(t.domestic?"CN":"GL"));
            if (r==null) continue;
            report.append(t.domestic?"国内 ":"国际 ").append(t.name).append(" ").append(t.url)
                    .append("\n首响应 ").append(fmt(r.medianResponse()))
                    .append("；HTTP ").append(r.lastStatus())
                    .append("；响应 ").append(r.reached()).append("/").append(Probe.ATTEMPTS)
                    .append("；抖动 ").append(fmt(r.jitter()))
                    .append("；正文累计 ").append(fmt(r.medianBody())).append("\n");
        }
        report.append("\n");
        for (SpeedTester.Result s:speedResults) report.append(s.label()).append("\n");
        report.append("\n测量方法：HTTPS GET 响应头耗时；网页正文最多读取 256KiB。\n");
        ClipboardManager clip=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        if (clip!=null) clip.setPrimaryClip(ClipData.newPlainText("NetPulse report",report.toString()));
        Intent send=new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT,report.toString());
        startActivity(Intent.createChooser(send,"分享测试报告（已复制到剪贴板）"));
    }

    private void updateNetwork() {
        if (networkLabel==null || connectivity==null) return;
        try {
            Network active=connectivity.getActiveNetwork();
            if (active==null) { networkLabel.setText("未连接任何默认网络"); return; }
            NetworkCapabilities cap=connectivity.getNetworkCapabilities(active);
            if (cap==null) { networkLabel.setText("网络状态未知"); return; }
            StringBuilder sb=new StringBuilder();
            if (cap.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) sb.append("VPN · ");
            if (cap.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) sb.append("Wi-Fi · ");
            if (cap.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) sb.append("蜂窝网络 · ");
            if (cap.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) sb.append("以太网 · ");
            if (sb.length()==0) sb.append("其他网络 · ");
            sb.append(cap.hasCapability(NetworkCapabilities.NET_CAPABILITY_VALIDATED) ? "已验证联网":"未经系统验证");
            networkLabel.setText(sb.toString());
        } catch(Exception ignored) {
            networkLabel.setText("无法读取默认网络");
        }
    }

    private String fmt(double ms) {
        return ms<0 ? "—" : String.format(Locale.CHINA,"%.0f ms",ms);
    }
    private void toast(String message) { Toast.makeText(this,message,Toast.LENGTH_SHORT).show(); }
    private int dp(float value) { return (int)(value*getResources().getDisplayMetrics().density+.5f); }
    private TextView label(String text,int sp,int color,boolean bold) {
        TextView tv=new TextView(this);
        tv.setText(text);
        tv.setTextSize(sp);
        tv.setTextColor(color);
        if (bold) tv.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return tv;
    }
    private GradientDrawable round(int color,float radiusDp) {
        GradientDrawable gd=new GradientDrawable();
        gd.setColor(color);
        gd.setCornerRadius(dp(radiusDp));
        return gd;
    }
    private LinearLayout card(LinearLayout parent) {
        LinearLayout c=new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(dp(15),dp(15),dp(15),dp(15));
        c.setBackground(round(CARD,15));
        parent.addView(c,new LinearLayout.LayoutParams(-1,-2));
        return c;
    }
    private LinearLayout horizontal(LinearLayout parent) {
        LinearLayout row=new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        parent.addView(row,new LinearLayout.LayoutParams(-1,-2));
        return row;
    }
    private Button action(String name,int background,int color,boolean bold) {
        Button b=new Button(this);
        b.setText(name);
        b.setTextColor(color);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setMinHeight(0);
        b.setMinimumHeight(0);
        b.setPadding(dp(5),dp(7),dp(5),dp(7));
        b.setBackground(round(background,12));
        if (bold) b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);
        return b;
    }
    private LinearLayout.LayoutParams weightedButton() {
        return new LinearLayout.LayoutParams(0,dp(46),1);
    }
    private void addSpace(LinearLayout to,int height) {
        View v=new View(this);
        to.addView(v,new LinearLayout.LayoutParams(1,dp(height)));
    }
    private void addHorizontalSpace(LinearLayout to,int width) {
        View v=new View(this);
        to.addView(v,new LinearLayout.LayoutParams(dp(width),1));
    }
    @Override protected void onDestroy() {
        generation.incrementAndGet();
        if (executor!=null) executor.shutdownNow();
        if (speedThread!=null) speedThread.interrupt();
        if (connectivity!=null && netCallback!=null) {
            try { connectivity.unregisterNetworkCallback(netCallback); } catch(Exception ignored) {}
        }
        super.onDestroy();
    }
}
