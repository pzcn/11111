package com.example.netpulse;

import android.os.SystemClock;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Locale;

final class SpeedTester {
    private static final int DOWNLOAD_MAX = 16 * 1024 * 1024;
    private static final int UPLOAD_BYTES = 4 * 1024 * 1024;
    private static final long MAX_DOWNLOAD_MS = 20_000;

    static final class Result {
        final String name;
        final double mbps;
        final long bytes;
        final String error;
        Result(String name, double mbps, long bytes, String error) {
            this.name=name; this.mbps=mbps; this.bytes=bytes; this.error=error;
        }
        boolean ok() { return error == null; }
        String label() {
            if (!ok()) return name + "：失败（" + error + "）";
            return String.format(Locale.CHINA, "%s：%.2f Mbps（%.1f MB）", name,
                    mbps, bytes/1_000_000d);
        }
    }

    static Result download(String name, String address, Probe.CancelCheck check) {
        HttpURLConnection c = null;
        long bytes = 0;
        try {
            c = (HttpURLConnection) new URL(address).openConnection();
            c.setConnectTimeout(6000);
            c.setReadTimeout(7000);
            c.setUseCaches(false);
            c.setInstanceFollowRedirects(true);
            c.setRequestProperty("Cache-Control", "no-cache");
            c.setRequestProperty("Accept-Encoding", "identity");
            c.setRequestProperty("Connection", "close");
            int status=c.getResponseCode();
            if (status < 200 || status >= 300) throw new IOException("HTTP " + status);
            long start=SystemClock.elapsedRealtimeNanos();
            try (InputStream in = c.getInputStream()) {
                byte[] buffer = new byte[64 * 1024];
                int n;
                while (!check.cancelled() && bytes < DOWNLOAD_MAX &&
                        (n=in.read(buffer, 0, (int)Math.min(buffer.length, DOWNLOAD_MAX-bytes))) != -1) {
                    bytes += n;
                    if (millisSince(start) >= MAX_DOWNLOAD_MS) break;
                }
            }
            if (check.cancelled()) return new Result(name, 0, bytes, "已取消");
            if (bytes < 512 * 1024) throw new IOException("文件太小，不能可靠测速");
            double elapsed=Math.max(0.001, millisSince(start)/1000d);
            double mbps=bytes*8d/(elapsed*1_000_000d);
            return new Result(name,mbps,bytes,null);
        } catch (Exception ex) {
            return new Result(name,0,bytes,shortError(ex));
        } finally {
            if (c!=null) c.disconnect();
        }
    }

    static Result uploadCloudflare(Probe.CancelCheck check) {
        final String name = "国际上传（Cloudflare）";
        HttpURLConnection c=null;
        long bytes=0;
        try {
            c=(HttpURLConnection)new URL("https://speed.cloudflare.com/__up").openConnection();
            c.setRequestMethod("POST");
            c.setDoOutput(true);
            c.setConnectTimeout(6000);
            c.setReadTimeout(10000);
            c.setUseCaches(false);
            c.setRequestProperty("Content-Type","application/octet-stream");
            c.setFixedLengthStreamingMode(UPLOAD_BYTES);
            byte[] buffer = new byte[32 * 1024];
            java.util.Random random = new java.util.Random();
            random.nextBytes(buffer);
            long start;
            try (OutputStream out = c.getOutputStream()) {
                start=SystemClock.elapsedRealtimeNanos();
                while (bytes < UPLOAD_BYTES) {
                    if (check.cancelled()) return new Result(name,0,bytes,"已取消");
                    int n=(int)Math.min(buffer.length,UPLOAD_BYTES-bytes);
                    out.write(buffer,0,n);
                    bytes+=n;
                }
                out.flush();
            }
            int status=c.getResponseCode();
            if (status < 200 || status >= 300) throw new IOException("HTTP " + status);
            double seconds=Math.max(.001,millisSince(start)/1000d);
            return new Result(name,bytes*8d/(seconds*1_000_000d),bytes,null);
        } catch(Exception ex) {
            return new Result(name,0,bytes,shortError(ex));
        } finally {
            if (c!=null) c.disconnect();
        }
    }

    private static double millisSince(long nanos) {
        return (SystemClock.elapsedRealtimeNanos()-nanos)/1_000_000d;
    }
    private static String shortError(Exception ex) {
        String msg=ex.getLocalizedMessage();
        if (msg==null || msg.isEmpty()) msg=ex.getClass().getSimpleName();
        return msg.length()>90 ? msg.substring(0,90) : msg;
    }
}
